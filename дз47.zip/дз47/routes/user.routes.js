import express from 'express';
import { UserController } from '../controllers/user.controllers.js';

const router = express.Router();
const userController = new UserController();

router.post('/', userController.createUser);
router.post('/signin', userController.signinUser);
router.get('/', userController.getAllUser);
router.get('/:id', userController.getUserById);
router.put('/:id', userController.updateUser);
router.delete('/:id', userController.deleteUser);

export default router;