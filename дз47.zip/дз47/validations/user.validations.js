import Joi from "joi";

const userValidations = {
    createUser: Joi.object({
        username: Joi.string().required(),
        password: Joi.string().min(6).required(),
        role: Joi.string().valid('user')
    }),
    loginUser: Joi.object({
        username: Joi.string().required(),
        password: Joi.string().required()
    })
};
export default userValidations;