import express from 'express';
import { config } from 'dotenv';
import mongoose from 'mongoose';
import userRouter from './routes/user.routes.js';

config();
const app = express();
const port = parseInt(process.env.PORT) || 3000;
const dbUrl = process.env.MONGO_URI;

app.use(express.json());
app.use('/users', userRouter);

mongoose.connect(dbUrl)
    .then(() => console.log('Database connected'))
    .catch(err => console.error(`Error on db ${dbUrl}: ${err.message}`));

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});