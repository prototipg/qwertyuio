import User from '../models/user.models.js';
import userValidations from '../validations/user.validations.js';
import * as bcrypt from 'bcrypt';

export class UserController {
    async createUser(req, res) {
        try {
            const { error } = userValidations.createUser.validate(req.body);
            if (error) {
                return res.status(400).json({ error: error.details[0].message });
            }
            const { username, password, role } = req.body;
            const hashedPassword = await bcrypt.hash(password, 7);
            const user = await User.create({ username, password: hashedPassword, role });
            return res.status(201).json({
                statusCode: 201,
                message: 'Пользователь успешно создан',
                data: user
            });
        } catch (error) {
            return res.status(500).json({
                statusCode: 500,
                error: error.message
            });
        }
    }

    async getAllUser(req, res) {
        try {
            const users = await User.find();
            return res.status(200).json({
                statusCode: 200,
                data: users
            });
        } catch (error) {
            return res.status(500).json({
                statusCode: 500,
                error: error.message
            });
        }
    }

    async getUserById(req, res) {
        try {
            const user = await User.findById(req.params.id);
            if (!user) {
                return res.status(404).json({
                    statusCode: 404,
                    error: 'Пользователь не найден'
                });
            }
            return res.status(200).json({
                statusCode: 200,
                data: user
            });
        } catch (error) {
            return res.status(500).json({
                statusCode: 500,
                error: error.message
            });
        }
    }

    async updateUser(req, res) {
        try {
            const { error } = userValidations.createUser.validate(req.body);
            if (error) {
                return res.status(400).json({ error: error.details[0].message });
            }
            const user = await User.findByIdAndUpdate(req.params.id, req.body, {
                new: true,
                runValidators: true
            });
            if (!user) {
                return res.status(404).json({
                    statusCode: 404,
                    error: 'Пользователь не найден'
                });
            }
            return res.status(200).json({
                statusCode: 200,
                message: 'Пользователь обновлен',
                data: user
            });
        } catch (error) {
            return res.status(500).json({
                statusCode: 500,
                error: error.message
            });
        }
    }

    async deleteUser(req, res) {
        try {
            const user = await User.findByIdAndDelete(req.params.id);
            if (!user) {
                return res.status(404).json({
                    statusCode: 404,
                    error: 'Пользователь не найден'
                });
            }
            return res.status(200).json({
                statusCode: 200,
                message: 'Пользователь удален'
            });
        } catch (error) {
            return res.status(500).json({
                statusCode: 500,
                error: error.message
            });
        }
    }

    async signinUser(req, res) {
        try {
            const { error } = userValidations.loginUser.validate(req.body);
            if (error) {
                return res.status(400).json({ error: error.details[0].message });
            }
            const { username, password } = req.body;
            const user = await User.findOne({ username });
            if (!user) {
                return res.status(404).json({
                    statusCode: 404,
                    error: 'Пользователь не найден'
                });
            }
            const isPasswordValid = await bcrypt.compare(password, user.password);
            if (!isPasswordValid) {
                return res.status(401).json({
                    statusCode: 401,
                    error: 'Неверный пароль'
                });
            }
            return res.status(200).json({
                statusCode: 200,
                message: 'Успешный вход',
                data: user
            });
        } catch (error) {
            return res.status(500).json({
                statusCode: 500,
                error: error.message
            });
        }
    }
}